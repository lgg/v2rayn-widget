import fs from 'node:fs';

function read(path) { return fs.readFileSync(path, 'utf8'); }
function write(path, content) { fs.mkdirSync(path.substring(0, path.lastIndexOf('/')), { recursive: true }); fs.writeFileSync(path, content); }
function replaceOnce(path, before, after) {
  const source = read(path);
  const first = source.indexOf(before);
  if (first < 0) throw new Error(`Missing expected block in ${path}: ${before.slice(0, 100)}`);
  if (source.indexOf(before, first + before.length) >= 0) throw new Error(`Expected unique block in ${path}`);
  write(path, source.slice(0, first) + after + source.slice(first + before.length));
}
function appendBeforeLast(path, marker, content) {
  const source = read(path);
  const index = source.lastIndexOf(marker);
  if (index < 0) throw new Error(`Missing final marker in ${path}`);
  write(path, source.slice(0, index) + content + source.slice(index));
}

// Listener readiness closes the asynchronous registration gap.
replaceOnce('src/frontend/src/lib/tauri-listener.ts',
`  onError?: (error: unknown) => void,\n): () => void {`,
`  onError?: (error: unknown) => void,\n  onReady?: () => void,\n): () => void {`);
replaceOnce('src/frontend/src/lib/tauri-listener.ts',
`      unlisten = dispose;\n    })`,
`      unlisten = dispose;\n      onReady?.();\n    })`);
appendBeforeLast('src/frontend/src/lib/tauri-listener.test.ts', '\n});', `

  it("signals readiness only after the listener is registered", async () => {
    let resolveListen: ((dispose: () => void) => void) | undefined;
    const onReady = vi.fn();
    listenMock.mockReturnValue(
      new Promise<() => void>((resolve) => {
        resolveListen = resolve;
      }),
    );

    const cleanup = bindTauriListener("event", () => undefined, undefined, onReady);
    expect(onReady).not.toHaveBeenCalled();

    resolveListen?.(() => undefined);
    await Promise.resolve();
    expect(onReady).toHaveBeenCalledOnce();
    cleanup();
  });
`);

// Main registers all authoritative listeners before bootstrap.
replaceOnce('src/frontend/src/app/App.tsx',
`import { useEffect, useMemo, useRef } from "react";`,
`import { useEffect, useMemo, useRef, useState } from "react";`);
replaceOnce('src/frontend/src/app/App.tsx',
`  const skippedInitialOperationalRefresh = useRef(false);\n`,
`  const skippedInitialOperationalRefresh = useRef(false);\n  const [eventListenersSettled, setEventListenersSettled] = useState(false);\n`);
replaceOnce('src/frontend/src/app/App.tsx',
`  useEffect(() => {\n    void bootstrap();\n  }, [bootstrap]);\n`,
`  useEffect(() => {\n    let active = true;\n    let settled = 0;\n    const markSettled = (): void => {\n      if (!active) return;\n      settled += 1;\n      if (settled === 3) setEventListenersSettled(true);\n    };\n\n    setEventListenersSettled(false);\n    const disposers = [\n      bindTauriListener<AppSettings>(\n        "settings-updated",\n        (event) => applyExternalSettings(event.payload),\n        markSettled,\n        markSettled,\n      ),\n      bindTauriListener<TrayStatusUpdate>(\n        "tray-status-updated",\n        (event) => applyExternalStatus(event.payload),\n        markSettled,\n        markSettled,\n      ),\n      bindTauriListener<TrayOperationError>(\n        "tray-operation-error",\n        (event) => applyExternalOperationError(event.payload),\n        markSettled,\n        markSettled,\n      ),\n    ];\n\n    return () => {\n      active = false;\n      for (const dispose of disposers) dispose();\n    };\n  }, [applyExternalOperationError, applyExternalSettings, applyExternalStatus]);\n\n  useEffect(() => {\n    if (eventListenersSettled) void bootstrap();\n  }, [bootstrap, eventListenersSettled]);\n`);
replaceOnce('src/frontend/src/app/App.tsx',
`  useEffect(\n    () =>\n      bindTauriListener<AppSettings>("settings-updated", (event) => {\n        applyExternalSettings(event.payload);\n      }),\n    [applyExternalSettings],\n  );\n\n  useEffect(\n    () =>\n      bindTauriListener<TrayStatusUpdate>("tray-status-updated", (event) => {\n        applyExternalStatus(event.payload);\n      }),\n    [applyExternalStatus],\n  );\n\n  useEffect(\n    () =>\n      bindTauriListener<TrayOperationError>("tray-operation-error", (event) => {\n        applyExternalOperationError(event.payload);\n      }),\n    [applyExternalOperationError],\n  );\n\n`, ``);

// Exact RFC3339 nanosecond freshness.
write('src/frontend/src/features/status-freshness.ts', `import type { DashboardStatus } from "@/lib/types";

const RFC3339_INSTANT = /^(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})(?:\\.(\\d{1,9}))?(Z|[+-]\\d{2}:\\d{2})$/;

export function parseStatusInstant(value: string): bigint | null {
  const match = RFC3339_INSTANT.exec(value.trim());
  if (!match) return null;

  const milliseconds = Date.parse(value);
  if (!Number.isFinite(milliseconds)) return null;

  const fraction = (match[2] ?? "").padEnd(9, "0");
  const subMillisecondNanoseconds = BigInt(fraction.slice(3) || "0");
  return BigInt(milliseconds) * 1_000_000n + subMillisecondNanoseconds;
}

export function statusIsAtLeastAsFresh(
  candidate: DashboardStatus,
  current: DashboardStatus | null,
): boolean {
  if (!current) return true;

  const candidateTime = parseStatusInstant(candidate.updated_at);
  const currentTime = parseStatusInstant(current.updated_at);
  if (candidateTime !== null && currentTime !== null) return candidateTime >= currentTime;
  if (candidateTime === null && currentTime !== null) return false;
  return true;
}
`);
write('src/frontend/src/features/status-freshness.test.ts', `import { describe, expect, it } from "vitest";
import { parseStatusInstant, statusIsAtLeastAsFresh } from "@/features/status-freshness";
import type { DashboardStatus } from "@/lib/types";

function status(updated_at: string): DashboardStatus {
  return {
    status: "Connected", tun_enabled: true, connection_state: "Connected",
    active_profile_name: null, external_ip: null, latency_ms: null,
    last_error: null, last_event: null, updated_at,
  };
}

describe("status freshness", () => {
  it("preserves sub-millisecond RFC3339 ordering", () => {
    const newer = status("2026-07-31T10:00:00.123456789Z");
    const older = status("2026-07-31T10:00:00.123456788Z");
    expect(parseStatusInstant(newer.updated_at)).toBeGreaterThan(parseStatusInstant(older.updated_at)!);
    expect(statusIsAtLeastAsFresh(older, newer)).toBe(false);
    expect(statusIsAtLeastAsFresh(newer, older)).toBe(true);
  });

  it("rejects an invalid candidate against a valid current timestamp", () => {
    expect(statusIsAtLeastAsFresh(status("invalid"), status("2026-07-31T10:00:00Z"))).toBe(false);
    expect(statusIsAtLeastAsFresh(status("2026-07-31T10:00:00Z"), status("invalid"))).toBe(true);
  });
});
`);
replaceOnce('src/frontend/src/features/dashboard-store.ts',
`import { activeClientOperationalContextChanged } from "@/features/active-client-context";\n`,
`import { activeClientOperationalContextChanged } from "@/features/active-client-context";\nimport { statusIsAtLeastAsFresh } from "@/features/status-freshness";\n`);
replaceOnce('src/frontend/src/features/dashboard-store.ts',
`function statusIsAtLeastAsFresh(\n  candidate: DashboardStatus,\n  current: DashboardStatus | null,\n): boolean {\n  if (!current) {\n    return true;\n  }\n\n  const candidateTime = Date.parse(candidate.updated_at);\n  const currentTime = Date.parse(current.updated_at);\n  if (!Number.isFinite(candidateTime) || !Number.isFinite(currentTime)) {\n    return true;\n  }\n\n  return candidateTime >= currentTime;\n}\n\n`, ``);
replaceOnce('src/frontend/src/features/dashboard-store.ts',
`      const [settings, clients] = await Promise.all([\n        getSettings(),\n        getClientCatalog(),\n      ]);\n      applyTheme(settings.theme);`,
`      const [settings, clients] = await Promise.all([\n        getSettings(),\n        getClientCatalog(),\n      ]);\n      if (generation !== clientGeneration || revision !== settingsRevision) {\n        return;\n      }\n      applyTheme(settings.theme);`);
replaceOnce('src/frontend/src/features/dashboard-store.ts',
`    const generation = clientGeneration;\n    const catalogRequest = ++catalogRequestRevision;\n    void getClientCatalog()`,
`    if (previousSettings === null) {\n      const initialGeneration = clientGeneration;\n      const initialClientId = settings.selected_client;\n      void Promise.all([\n        refreshSelectedClientStartup().catch(() =>\n          getStatus().catch(() => defaultStatus()),\n        ),\n        listSelectedClientItems().catch(() => []),\n      ]).then(([status, profiles]) => {\n        if (!clientOperationIsCurrent(initialGeneration, initialClientId)) return;\n        set((previous) => {\n          const accept = statusIsAtLeastAsFresh(status, previous.status);\n          return {\n            status: accept ? status : previous.status,\n            profiles: accept ? profiles : previous.profiles,\n          };\n        });\n      });\n    }\n\n    const generation = clientGeneration;\n    const catalogRequest = ++catalogRequestRevision;\n    void getClientCatalog()`);
appendBeforeLast('src/frontend/src/features/dashboard-store-active-context.test.ts', '\n});', `

  it("refreshes the initial client when a settings event supersedes bootstrap", async () => {
    useDashboardStore.setState({ settings: null, status: null, profiles: [], loading: true });
    apiMocks.refreshSelectedClientStartup.mockResolvedValueOnce(
      connectedStatus("2026-07-31T00:00:05.123456789Z"),
    );
    apiMocks.listSelectedClientItems.mockResolvedValueOnce([
      { id: "initial", name: "initial-profile" },
    ]);

    useDashboardStore.getState().applyExternalSettings(baseSettings);
    await Promise.resolve();
    await Promise.resolve();
    await Promise.resolve();

    expect(useDashboardStore.getState().status?.updated_at).toBe(
      "2026-07-31T00:00:05.123456789Z",
    );
    expect(useDashboardStore.getState().profiles).toEqual([
      { id: "initial", name: "initial-profile" },
    ]);
  });
`);

// Settings and Happ Setup wait for listener registration and authoritative events end loading.
replaceOnce('src/frontend/src/app/SettingsWindow.tsx',
`  const settingsRevisionRef = useRef(0);\n`,
`  const settingsRevisionRef = useRef(0);\n  const [settingsListenerSettled, setSettingsListenerSettled] = useState(false);\n`);
replaceOnce('src/frontend/src/app/SettingsWindow.tsx',
`  useEffect(() => {\n    let active = true;\n    const revision = settingsRevisionRef.current;`,
`  useEffect(() => {\n    if (!settingsListenerSettled) return;\n    let active = true;\n    const revision = settingsRevisionRef.current;`);
replaceOnce('src/frontend/src/app/SettingsWindow.tsx',
`  }, [i18n, loadAttempt]);`,
`  }, [i18n, loadAttempt, settingsListenerSettled]);`);
replaceOnce('src/frontend/src/app/SettingsWindow.tsx',
`  useEffect(\n    () =>\n      bindTauriListener<AppSettings>("settings-updated", (event) => {\n        settingsRevisionRef.current += 1;`,
`  useEffect(() => {\n    setSettingsListenerSettled(false);\n    return bindTauriListener<AppSettings>("settings-updated", (event) => {\n        settingsRevisionRef.current += 1;\n        setLoading(false);\n        setLoadError(null);`);
replaceOnce('src/frontend/src/app/SettingsWindow.tsx',
`        void i18n.changeLanguage(event.payload.language);\n      }),\n    [i18n],\n  );`,
`        void i18n.changeLanguage(event.payload.language);\n      },\n      () => setSettingsListenerSettled(true),\n      () => setSettingsListenerSettled(true),\n    );\n  }, [i18n]);`);
appendBeforeLast('src/frontend/src/app/SettingsWindow.test.tsx', '\n});', `

  it("registers settings events before loading and leaves loading on an authoritative event", async () => {
    let settingsHandler: ((event: { payload: AppSettings }) => void) | undefined;
    apiMocks.getSettings.mockReturnValueOnce(new Promise<AppSettings>(() => undefined));
    eventMocks.listen.mockImplementation(async (eventName: string, handler: (event: { payload: AppSettings }) => void) => {
      if (eventName === "settings-updated") settingsHandler = handler;
      return () => undefined;
    });

    render(<SettingsWindow />);
    await waitFor(() => expect(settingsHandler).toBeDefined());
    await act(async () => settingsHandler?.({ payload: { ...baseSettings, theme: "light" } }));

    expect(await screen.findByRole("heading", { name: "Settings" })).not.toBeNull();
    expect(document.documentElement.classList.contains("dark")).toBe(false);
  });
`);

replaceOnce('src/frontend/src/app/HappSetupWindow.tsx',
`  const settingsRevisionRef = useRef(0);\n`,
`  const settingsRevisionRef = useRef(0);\n  const [settingsListenerSettled, setSettingsListenerSettled] = useState(false);\n`);
replaceOnce('src/frontend/src/app/HappSetupWindow.tsx',
`  useEffect(() => {\n    let active = true;\n    const revision = settingsRevisionRef.current;`,
`  useEffect(() => {\n    if (!settingsListenerSettled) return;\n    let active = true;\n    const revision = settingsRevisionRef.current;`);
replaceOnce('src/frontend/src/app/HappSetupWindow.tsx',
`  }, [i18n, loadAttempt]);`,
`  }, [i18n, loadAttempt, settingsListenerSettled]);`);
replaceOnce('src/frontend/src/app/HappSetupWindow.tsx',
`  useEffect(\n    () =>\n      bindTauriListener<AppSettings>("settings-updated", (event) => {\n        settingsRevisionRef.current += 1;`,
`  useEffect(() => {\n    setSettingsListenerSettled(false);\n    return bindTauriListener<AppSettings>("settings-updated", (event) => {\n        settingsRevisionRef.current += 1;\n        setLoading(false);\n        setError(null);`);
replaceOnce('src/frontend/src/app/HappSetupWindow.tsx',
`        void applySurfaceSettings(event.payload);\n      }),\n    [],\n  );`,
`        void applySurfaceSettings(event.payload);\n      },\n      () => setSettingsListenerSettled(true),\n      () => setSettingsListenerSettled(true),\n    );\n  }, []);`);
appendBeforeLast('src/frontend/src/app/HappSetupWindow.test.tsx', '\n});', `

  it("leaves loading when an authoritative event supersedes a hanging initial load", async () => {
    let settingsHandler: ((event: { payload: AppSettings }) => void) | undefined;
    apiMocks.getSettings.mockReturnValueOnce(new Promise<AppSettings>(() => undefined));
    eventMocks.listen.mockImplementation(async (eventName: string, handler: (event: { payload: AppSettings }) => void) => {
      if (eventName === "settings-updated") settingsHandler = handler;
      return () => undefined;
    });

    render(<HappSetupWindow />);
    await waitFor(() => expect(settingsHandler).toBeDefined());
    await act(async () => settingsHandler?.({ payload: settings }));

    expect(await screen.findByRole("heading", { name: "Happ adapter setup" })).not.toBeNull();
  });
`);

// Debug settings load also waits for listener readiness.
replaceOnce('src/frontend/src/app/DebugWindow.tsx',
`  const settingsRevisionRef = useRef(0);\n`,
`  const settingsRevisionRef = useRef(0);\n  const [settingsListenerSettled, setSettingsListenerSettled] = useState(false);\n`);
replaceOnce('src/frontend/src/app/DebugWindow.tsx',
`  useEffect(() => {\n    let active = true;\n    const revision = settingsRevisionRef.current;`,
`  useEffect(() => {\n    if (!settingsListenerSettled) return;\n    let active = true;\n    const revision = settingsRevisionRef.current;`);
replaceOnce('src/frontend/src/app/DebugWindow.tsx',
`  }, []);\n\n  useEffect(\n    () =>\n      bindTauriListener<AppSettings>("settings-updated", (event) => {\n        settingsRevisionRef.current += 1;\n        void applySurfaceSettings(event.payload);\n      }),\n    [],\n  );`,
`  }, [settingsListenerSettled]);\n\n  useEffect(() => {\n    setSettingsListenerSettled(false);\n    return bindTauriListener<AppSettings>(\n      "settings-updated",\n      (event) => {\n        settingsRevisionRef.current += 1;\n        void applySurfaceSettings(event.payload);\n      },\n      () => setSettingsListenerSettled(true),\n      () => setSettingsListenerSettled(true),\n    );\n  }, []);`);
replaceOnce('src/frontend/src/app/DebugWindow.test.tsx',
`    listenerMocks.bindTauriListener.mockReturnValue(() => undefined);`,
`    listenerMocks.bindTauriListener.mockImplementation((_eventName: string, _handler: unknown, _onError?: unknown, onReady?: () => void) => {\n      onReady?.();\n      return () => undefined;\n    });`);
replaceOnce('src/frontend/src/app/DebugWindow.test.tsx',
`    listenerMocks.bindTauriListener.mockImplementation((eventName: string, handler: (event: { payload: AppSettings }) => void) => {\n      if (eventName === "settings-updated") {\n        settingsHandler = handler;\n      }\n      return () => undefined;\n    });`,
`    listenerMocks.bindTauriListener.mockImplementation((eventName: string, handler: (event: { payload: AppSettings }) => void, _onError?: unknown, onReady?: () => void) => {\n      if (eventName === "settings-updated") settingsHandler = handler;\n      onReady?.();\n      return () => undefined;\n    });`);
replaceOnce('src/frontend/src/app/DebugWindow.test.tsx',
`    listenerMocks.bindTauriListener.mockImplementation((eventName: string, handler: (event: { payload: AppSettings }) => void) => {\n      if (eventName === "settings-updated") {\n        settingsHandler = handler;\n      }\n      return () => undefined;\n    });`,
`    listenerMocks.bindTauriListener.mockImplementation((eventName: string, handler: (event: { payload: AppSettings }) => void, _onError?: unknown, onReady?: () => void) => {\n      if (eventName === "settings-updated") settingsHandler = handler;\n      onReady?.();\n      return () => undefined;\n    });`);
replaceOnce('src/frontend/src/app/DebugWindow.test.tsx',
`    listenerMocks.bindTauriListener.mockImplementation((eventName: string, handler: () => void) => {\n      if (eventName === "debug-close-requested") {\n        nativeCloseHandler = handler;\n      }\n      return () => undefined;\n    });`,
`    listenerMocks.bindTauriListener.mockImplementation((eventName: string, handler: () => void, _onError?: unknown, onReady?: () => void) => {\n      if (eventName === "debug-close-requested") nativeCloseHandler = handler;\n      onReady?.();\n      return () => undefined;\n    });`);
appendBeforeLast('src/frontend/src/app/DebugWindow.test.tsx', '\n});', `

  it("does not request settings before the settings listener is registered", async () => {
    let ready: (() => void) | undefined;
    listenerMocks.bindTauriListener.mockImplementation((eventName: string, _handler: unknown, _onError?: unknown, onReady?: () => void) => {
      if (eventName === "settings-updated") ready = onReady;
      else onReady?.();
      return () => undefined;
    });

    render(<DebugWindow />);
    expect(apiMocks.getSettings).not.toHaveBeenCalled();
    await act(async () => ready?.());
    await waitFor(() => expect(apiMocks.getSettings).toHaveBeenCalledOnce());
  });
`);

// Backend tray ownership is captured once and stale outcomes are suppressed.
replaceOnce('src/tauri/src/client_commands.rs',
`const CLIENT_CONTEXT_CHANGED: &str =\n    "CLIENT_CONTEXT_CHANGED: selected proxy client changed while the operation was running";\n`,
`const CLIENT_CONTEXT_CHANGED: &str =\n    "CLIENT_CONTEXT_CHANGED: selected proxy client changed while the operation was running";\n\npub(crate) struct SelectedClientOperation<T> {\n    pub client_id: ProxyClientId,\n    pub context_current: bool,\n    pub result: Result<T, String>,\n}\n`);
replaceOnce('src/tauri/src/client_commands.rs',
`async fn refresh_with_kind(\n    state: State<'_, AppState>,\n    kind: RefreshKind,\n) -> Result<DashboardStatus, String> {\n    let snapshot = state.snapshot();\n    let client_id = snapshot.settings.selected_client;\n    let client_epoch = snapshot.client_epoch;\n    let result = adapters::adapter(client_id)\n        .refresh(state.clone(), kind)\n        .await?;\n\n    if state.context_matches(client_id, client_epoch) {\n        Ok(result)\n    } else {\n        Err(CLIENT_CONTEXT_CHANGED.to_owned())\n    }\n}\n`,
`async fn refresh_with_kind_owned(\n    state: State<'_, AppState>,\n    kind: RefreshKind,\n) -> SelectedClientOperation<DashboardStatus> {\n    let snapshot = state.snapshot();\n    let client_id = snapshot.settings.selected_client;\n    let client_epoch = snapshot.client_epoch;\n    let result = adapters::adapter(client_id).refresh(state.clone(), kind).await;\n    let context_current = state.context_matches(client_id, client_epoch);\n    SelectedClientOperation { client_id, context_current, result }\n}\n\nasync fn refresh_with_kind(\n    state: State<'_, AppState>,\n    kind: RefreshKind,\n) -> Result<DashboardStatus, String> {\n    let outcome = refresh_with_kind_owned(state, kind).await;\n    if outcome.context_current { outcome.result } else { Err(CLIENT_CONTEXT_CHANGED.to_owned()) }\n}\n\npub(crate) async fn refresh_selected_client_from_tray(\n    state: State<'_, AppState>,\n) -> SelectedClientOperation<DashboardStatus> {\n    refresh_with_kind_owned(state, RefreshKind::Foreground).await\n}\n`);
replaceOnce('src/tauri/src/client_commands.rs',
`#[tauri::command]\npub async fn open_selected_client(state: State<'_, AppState>) -> Result<(), String> {\n    let client_id = state.snapshot().settings.selected_client;\n    adapters::adapter(client_id).open(state).await\n}\n`,
`async fn open_selected_client_owned(\n    state: State<'_, AppState>,\n) -> SelectedClientOperation<()> {\n    let snapshot = state.snapshot();\n    let client_id = snapshot.settings.selected_client;\n    let client_epoch = snapshot.client_epoch;\n    let result = adapters::adapter(client_id).open(state.clone()).await;\n    let context_current = state.context_matches(client_id, client_epoch);\n    SelectedClientOperation { client_id, context_current, result }\n}\n\npub(crate) async fn open_selected_client_from_tray(\n    state: State<'_, AppState>,\n) -> SelectedClientOperation<()> {\n    open_selected_client_owned(state).await\n}\n\n#[tauri::command]\npub async fn open_selected_client(state: State<'_, AppState>) -> Result<(), String> {\n    let outcome = open_selected_client_owned(state).await;\n    if outcome.context_current { outcome.result } else { Err(CLIENT_CONTEXT_CHANGED.to_owned()) }\n}\n`);
replaceOnce('src/tauri/src/main.rs',
`                            let state = app_handle.state::<AppState>();\n                            let client_id = state.snapshot().settings.selected_client;\n                            match client_commands::refresh_selected_client(state).await {`,
`                            let state = app_handle.state::<AppState>();\n                            let outcome = client_commands::refresh_selected_client_from_tray(state).await;\n                            if !outcome.context_current {\n                                info!(client_id = ?outcome.client_id, "suppressed stale tray refresh result");\n                                return;\n                            }\n                            let client_id = outcome.client_id;\n                            match outcome.result {`);
replaceOnce('src/tauri/src/main.rs',
`                            let state = app_handle.state::<AppState>();\n                            let client_id = state.snapshot().settings.selected_client;\n                            if let Err(error) = client_commands::open_selected_client(state).await {`,
`                            let state = app_handle.state::<AppState>();\n                            let outcome = client_commands::open_selected_client_from_tray(state).await;\n                            if !outcome.context_current {\n                                info!(client_id = ?outcome.client_id, "suppressed stale tray open result");\n                                return;\n                            }\n                            let client_id = outcome.client_id;\n                            if let Err(error) = outcome.result {`);

// CI must use a ready fixed drive and prove cleanup succeeded.
replaceOnce('.github/workflows/windows-quality.yml',
`          $drive = Get-PSDrive -PSProvider FileSystem |\n            Where-Object { $_.Root -and $_.Free -ge $minimumFreeBytes } |\n            Sort-Object Free -Descending |\n            Select-Object -First 1\n`,
`          $drive = [System.IO.DriveInfo]::GetDrives() |\n            Where-Object {\n              $_.IsReady -and\n              $_.DriveType -eq [System.IO.DriveType]::Fixed -and\n              $_.AvailableFreeSpace -ge $minimumFreeBytes\n            } |\n            Sort-Object AvailableFreeSpace -Descending |\n            Select-Object -First 1\n`);
replaceOnce('.github/workflows/windows-quality.yml',
`          $projectTargetRoot = Join-Path $drive.Root "github-ci-targets\\v2rayn-widget"`,
`          $projectTargetRoot = Join-Path $drive.RootDirectory.FullName "github-ci-targets\\v2rayn-widget"`);
replaceOnce('.github/workflows/windows-quality.yml',
`          $freeGb = [math]::Round($drive.Free / 1GB, 2)\n          Write-Host "Rust target directory: $targetDirectory on drive $($drive.Name): with $freeGb GB free"`,
`          $freeGb = [math]::Round($drive.AvailableFreeSpace / 1GB, 2)\n          Write-Host "Rust target directory: $targetDirectory on fixed drive $($drive.Name) with $freeGb GB free"`);
replaceOnce('.github/workflows/windows-quality.yml',
`        run: |\n          Remove-Item "src/frontend/dist" -Recurse -Force -ErrorAction SilentlyContinue\n          Remove-Item "src/tauri/target" -Recurse -Force -ErrorAction SilentlyContinue\n          Remove-Item "src/tauri/portable-release" -Recurse -Force -ErrorAction SilentlyContinue\n          if ($env:CARGO_TARGET_DIR) {\n            Remove-Item $env:CARGO_TARGET_DIR -Recurse -Force -ErrorAction SilentlyContinue\n          }`,
`        run: |\n          $paths = @(\n            "src/frontend/dist",\n            "src/tauri/target",\n            "src/tauri/portable-release"\n          )\n          if ($env:CARGO_TARGET_DIR) { $paths += $env:CARGO_TARGET_DIR }\n\n          $failures = @()\n          foreach ($path in $paths) {\n            Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue\n            if (Test-Path $path) { $failures += $path }\n          }\n          if ($failures.Count -gt 0) {\n            throw "Rust cleanup left generated paths: $($failures -join ', ')"\n          }`);
replaceOnce('scripts/test-workflow-contracts.mjs',
`    ["Get-PSDrive -PSProvider FileSystem", "spacious drive selection"],`,
`    ["[System.IO.DriveInfo]::GetDrives()", "fixed drive enumeration"],\n    ["DriveType -eq [System.IO.DriveType]::Fixed", "fixed drive restriction"],`);
replaceOnce('scripts/test-workflow-contracts.mjs',
`    ["src/tauri/portable-release/v2rayn-widget.exe", "stable portable artifact path"],`,
`    ["src/tauri/portable-release/v2rayn-widget.exe", "stable portable artifact path"],\n    ["Rust cleanup left generated paths", "verified Rust cleanup"],`);
replaceOnce('src/tauri/tests/quality_storage_contract.rs',
`    assert!(workflow.contains("Get-PSDrive -PSProvider FileSystem"));`,
`    assert!(workflow.contains("[System.IO.DriveInfo]::GetDrives()"));\n    assert!(workflow.contains("DriveType -eq [System.IO.DriveType]::Fixed"));`);
replaceOnce('src/tauri/tests/quality_storage_contract.rs',
`    assert!(workflow.contains("Remove-Item $env:CARGO_TARGET_DIR"));`,
`    assert!(workflow.contains("Rust cleanup left generated paths"));`);

// Permanent source contract for ownership/listener/freshness invariants.
appendBeforeLast('src/tauri/tests/product_surface_contracts.rs', '\n#[test]\nfn happ_toggle_confirms_before_restoring_the_original_minimized_state()', `
#[test]
fn async_native_results_are_owned_and_listener_first() {
    let main = include_str!("../src/main.rs");
    assert!(main.contains("refresh_selected_client_from_tray"));
    assert!(main.contains("open_selected_client_from_tray"));
    assert!(main.contains("suppressed stale tray refresh result"));

    let commands = include_str!("../src/client_commands.rs");
    assert!(commands.contains("pub context_current: bool"));
    assert!(commands.contains("let context_current = state.context_matches(client_id, client_epoch)"));

    let app = include_str!("../../frontend/src/app/App.tsx");
    assert!(app.contains("if (eventListenersSettled) void bootstrap()"));
    let store = include_str!("../../frontend/src/features/dashboard-store.ts");
    assert!(store.contains("if (previousSettings === null)"));
    assert!(store.contains("refreshSelectedClientStartup().catch"));
}

`);

write('project-tracking/tasks/0034-async-native-consistency.md', `# 0034 - Async and Native Consistency

## Status

Implementation complete on audit branch; exact-head verification and merge pending.

## Audited baseline

main commit b9f21bd2559738670d7f97bbe2a7a649ee7daec2.

## Confirmed findings

1. Tray commands captured selected_client separately from backend dispatch.
2. Date.parse lost Rust status sub-millisecond precision.
3. Settings and tray listeners registered after initial loads began.
4. A settings event could invalidate Main bootstrap without replacement startup refresh.
5. Settings and Happ Setup could remain loading after an authoritative event.
6. Release Quality allowed non-fixed drives and silently ignored cleanup failures.

## Acceptance criteria

- [x] Tray operations use one captured backend context and suppress stale outcomes.
- [x] RFC3339 nanosecond freshness is preserved.
- [x] Listener registration precedes settings bootstrap/load on every affected surface.
- [x] Initial settings events trigger startup status/profile refresh.
- [x] Authoritative events end auxiliary loading.
- [x] CI uses ready fixed drives and verifies cleanup.
- [x] Regressions cover the confirmed boundaries.
- [ ] Exact-head Release Quality passes.
- [ ] PR is squash-merged and evidence recorded.
`);
write('project-tracking/reports/0034-async-native-consistency-report.md', `# 0034 - Async and Native Consistency Audit Report

## Status

Implementation complete; exact-head verification pending.

## Corrections

- backend-owned tray operation envelopes capture client and epoch once;
- stale tray results/errors are suppressed instead of mislabeled;
- frontend compares full RFC3339 nanosecond instants;
- Main registers all authoritative listeners before bootstrap;
- Settings, Happ Setup and Debug register settings listeners before initial loads;
- an initial settings event starts an authoritative startup status/profile refresh;
- Settings and Happ Setup leave loading on authoritative events;
- Release Quality selects only ready fixed drives and fails when generated paths remain;
- frontend, Rust and source/workflow contracts cover each invariant.

## Verification

Pending permanent exact-head Release Quality.
`);

// Architecture summary.
const architecturePath = 'docs/architecture.md';
const architecture = read(architecturePath);
const anchor = '## Window lifecycle and geometry';
if (!architecture.includes(anchor)) throw new Error('architecture anchor missing');
write(architecturePath, architecture.replace(anchor, `## Async native consistency\n\nNative tray operations capture selected client and epoch once inside the backend command boundary. Results are emitted only while that exact context remains current. Frontend status ordering parses the full RFC3339 fractional precision emitted by Chrono. Settings-aware webviews register authoritative listeners before requesting snapshots, and an event that supersedes Main bootstrap starts a replacement startup refresh.\n\nRelease Quality selects only ready fixed local drives for isolated Cargo output and verifies every generated path is absent after cleanup.\n\n${anchor}`));

console.log('0034 patch applied');
